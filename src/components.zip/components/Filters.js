import React from 'react'

function Filters(props) {
    return (
        <div id="filters">
            <form>
                <label>Minimum</label>
                {/* Calls the "handleFiltersChange" method of the App component when value is changed */}
                <select name="minRating" value={props.minRating} onChange={props.onChange}>
                    {
                        props.maxRating >= 1 &&
                        <option value="1">1</option>
                    }
                    {
                        props.maxRating >= 2 &&
                        <option value="2">2</option>
                    }
                    {
                        props.maxRating >= 3 &&
                        <option value="3">3</option>
                    }
                    {
                        props.maxRating >= 4 &&
                        <option value="4">4</option>
                    }
                    {
                        props.maxRating >= 5 &&
                        <option value="5">5</option>
                    }
                </select>

                <label>Maximum</label>
                {/* Calls the "handleFiltersChange" method of the App component when value is changed */}
                <select name="maxRating" value={props.maxRating} onChange={props.onChange}>
                    {
                        props.minRating <= 1 &&
                        <option value="1">1</option>
                    }
                    {
                        props.minRating <= 2 &&
                        <option value="2">2</option>
                    }
                    {
                        props.minRating <= 3 &&
                        <option value="3">3</option>
                    }
                    {
                        props.minRating <= 4 &&
                        <option value="4">4</option>
                    }
                    {
                        props.minRating <= 5 &&
                        <option value="5">5</option>
                    }
                </select>
            </form>
        </div>
    )
}

export default Filters