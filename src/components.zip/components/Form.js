import React, { Component } from 'react'

class Form extends Component {
    constructor(props) {
        super(props);
        this.state = {
            name: "",
            address: "",
            comment: "",
            stars: ""
        }
        this.handleChange = this.handleChange.bind(this);
    }

    /**
    * Set the state of name, address, comment and stars
    * based on the input value by the user
    * 
    * @param {event} event
    */
    handleChange = (event) => {
        const { name, value } = event.target
        this.setState({
            [name]: value
        })
    }

    render() {
        return (
            <div id="form">
                {/* Calls the "handleFormSubmit" method of the App component when the form is submitted */}
                <form onSubmit={this.props.onSubmit}> {}
                    <input
                        name="name"
                        value={this.state.name}
                        onChange={this.handleChange}
                        placeholder="Name"
                    />
                    <input
                        name="address"
                        value={this.state.address}
                        onChange={this.handleChange}
                        placeholder="Address"
                    />
                    <label for="comment">Your review:</label>
                    <textarea name="comment" cols="10" rows="3" value={this.state.comment} onChange={this.handleChange}></textarea>
                    <label for="stars">&#9733;</label>
                    <select name="stars" value={this.state.stars} onChange={this.handleChange}>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                    <button type="submit">Submit</button>
                </form>
            </div>
        )
    }
}

export default Form