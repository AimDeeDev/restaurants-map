// import React from 'react';
// import Restaurant from './Restaurant';
// import '../style/SidePanel.css';

// function SidePanel(props) {
//     const restaurants = props.restaurants.map(
//         restaurant =>
//             <Restaurant
//                 key={restaurant.address}
//                 restaurant={restaurant}
//                 minRating={props.minRating}
//                 maxRating={props.maxRating}
//             />
//     );

//     return (
//         <div id="restaurants-list">{restaurants}</div>
//     )
// }

// export default SidePanel;