import React from 'react';

function Review(props) {
    return (
        <div className="review">
            <quote>{props.comment}</quote>
            <p>&#9733; {props.rating}</p>
        </div>
    )
}

export default Review